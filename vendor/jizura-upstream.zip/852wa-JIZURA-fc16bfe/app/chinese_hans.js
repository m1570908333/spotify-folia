/* Simplified Chinese part names (converted from the Traditional Chinese labels in app/chinese.js, with mainland
   wording). Styles, moods and the sample lyrics come from app/i18n_zh_hans.py. Internal IDs stay language independent. */
(() => {
  'use strict';
  const titles = {
    layout: {
      center: '居中', mixed: '大小混排', vcols: '竖排', marquee: '流动横幅', tile: '满版平铺',
      scatter: '散落', ring: '环形', wave: '波浪轨迹', huge: '超出画面', labels: '标签贴',
      condensed: '瘦长压缩', gloss: '注解', type: '打字', diag: '斜带', circle: '圆窗',
      stack: '残影堆叠', pill: '胶囊', lowerThird: '下方字幕条', corners: '对角配置', staircase: '阶梯',
      zigzag: '锯齿', arcTop: '彩虹弧', spiral: '螺旋', gridCells: '方格', dropCap: '首字放大',
      justified: '版心', frameBox: '画框', bubble: '对话框', subtitleBar: '字幕条', ticker: '新闻跑马灯',
      splitScreen: '二分割', mirror: '镜像', sideways: '横躺竖排', edgeFrame: '沿边环绕', perspective: '景深',
      hanko: '落款', genkou: '稿纸', panels: '漫画分格', filmstrip: '胶片', quote: '引用',
      ruler: '尺寸线', searchBar: '搜索框', chat: '聊天', notification: '通知', ticket: '票券',
      rain: '文字雨', hanging: '吊挂', orbit: '环绕', tunnel: '隧道', wordCloud: '文字云',
      bounceLine: '弹跳', elastic: '橡皮筋', crossBands: '交叉带', stickerBomb: '贴纸', neon: '霓虹',
      keycaps: '键帽', bubbles: '泡泡', slotMachine: '老虎机', flipBoard: '翻牌看板', credits: '片尾字幕',
      zoomRepeat: '连续放大', splitHalves: '上下分割', columnsBig: '大小竖排', circleWords: '同心圆', dotMatrix: '点阵显示',
      depthStack: '景深重叠', typeSpecimen: '字体样本', kanjiFocus: '单字强调', halfVertical: '直横混排', curtain: '布幕',
      equalizer: '等化器', tape: '胶带', magazine: '杂志跨页', headlineDeck: '标题与导言', contents: '目录',
      footnote: '注脚', proofread: '校样', numbered: '编号', poster: '海报', swissGrid: '瑞士网格',
      dictionary: '辞典', ema: '绘马', ransom: '剪报字', newspaper: '报纸', vinyl: '黑胶唱片',
      cassette: '卡带', bookSpine: '书背', polaroid: '拍立得', stampSheet: '邮票版张', postcard: '明信片',
      letterPaper: '信纸', calendar: '月历', chochin: '灯笼', routeMap: '路线图', stationSign: '站名牌',
      noren: '暖帘', tanzaku: '短签', omikuji: '御神签', kakejiku: '挂轴', shoji: '障子',
      clapper: '场记板', warningLabel: '警告标签', priceTag: '价格标签', nameTag: '名牌', stickyNotes: '便利贴',
      karuta: '歌牌', cube: '立方体', cylinder: '圆柱', flipCards: '翻卡', accordion: '风琴折',
      flag: '飘扬的旗', ribbon: '缎带', pendulum: '钟摆', pile: '文字堆', blocks: '积木',
      balloons: '文字气球', magnets: '磁铁', tiles: '文字磁砖', bulbs: '灯泡招牌', ledScroll: '电子跑马灯',
      billboard: '广告牌', crowdBubbles: '对话框群', crossword: '填字游戏', wordSearch: '找字游戏', puzzle: '拼图',
      shadowPlay: '皮影戏', kaleido: '万花筒', dominoes: '骨牌', burst: '爆炸', fisheye: '鱼眼镜头',
      wall: '墙面透视', origami: '折纸', zipper: '拉链', sliceStack: '切片堆叠', glitchGrid: '故障网格',
      mosaicTiles: '磁砖拼画', maskReveal: '文字窗', contour: '等高线', halftoneBig: '网点巨字', stencil: '镂空模板',
      title: '标题', interlude: '间奏'
    },
    enter: {
      cut: '直切', assemble: '分解→聚合', slice: '切片', type: '打字', pop: '弹出',
      drop: '落下', stretch: '伸缩', wipe: '擦除', blur: '模糊', spin: '旋转',
      flicker: '闪烁', scramble: '乱码', zoom: '缩放', riseMask: '由下浮现', dropMask: '由上浮现',
      slideL: '从左滑入', slideR: '从右滑入', slideWhole: '整体滑入', flipX: '纵轴翻转', flipY: '横轴翻转',
      domino: '骨牌', fold: '折叠展开', unroll: '卷轴展开', strokeDraw: '线稿到上色', outlineFill: '轮廓→填色',
      splitJoin: '上下合体', vSlice: '纵向切片', shutter: '快门', iris: '光圈', diagWipe: '斜向擦除',
      blinds: '百叶窗', checker: '棋盘格', randomOrder: '随机顺序', bounceBig: '大跳跃', squashDrop: '压扁着地',
      rubber: '橡皮拉伸', glitchIn: '故障浮现', echoIn: '残影聚合', whip: '急甩', skewIn: '倾斜',
      trackIn: '字距收拢', trackOut: '字距扩张', blurStagger: '模糊错落', fadeStagger: '逐字淡入', waveIn: '波浪起伏',
      spiralIn: '螺旋聚合', zoomOut: '巨大→原尺寸', resolve: '解码', magnet: '磁吸', inkBleed: '晕染',
      neonOn: '霓虹点亮', cursorSweep: '光标扫过', stamp: '盖章', springIn: '弹簧', pendulum: '钟摆',
      rollIn: '滚入', slingshot: '弹弓', rockSettle: '摇晃着地', bounceBall: '弹跳球', snapRail: '吸附对齐',
      fanOpen: '扇子展开', cylinder: '圆柱旋转', shuffle: '洗牌', stopMotion: '定格动画', ripple: '涟漪',
      zipper: '拉链', zoomAlt: '交错缩放', tiltUp: '站起', stickerPeel: '贴上贴纸', crumple: '揉皱还原',
      noteUnfold: '展开信纸', tornJoin: '撕纸拼合', splitFlap: '翻牌', overexpose: '过曝', glint: '反光一闪',
      loupe: '放大镜', filmFeed: '胶片滚动', backlight: '逆光', lightLeak: '漏光', heatHaze: '热浪扭曲',
      crtOn: 'CRT 开机', interlace: '交错扫描', loadingBar: '加载条', dither: '抖动', odometer: '数字滚轮',
      matrixRain: '数据雨', hatchFill: '斜线→实心', brushReveal: '笔触扫出', inkDrop: '墨滴', quarters: '四方聚合',
      invertBox: '反转挖空', printRegister: '套印错位', echoCount: '数拍进场', liquidFill: '水位上升', windBlown: '乘风而来',
      strokeOrder: '逐笔书写', clockWipe: '顺时针', shadowFirst: '影子先落', bubbles: '泡泡', tokoroten: '挤压成条'
    },
    hold: {
      still: '静止', jitter: '抖动', drift: '漂移', breathe: '呼吸', wave: '波浪',
      glitchtick: '故障', float: '轻飘飘', sway: '摇曳', pulse: '脉动', shimmer: '闪耀',
      colorRun: '流动色彩', rotateSlow: '缓慢旋转', trackBreathe: '字距呼吸', skewWobble: '斜向摇晃', beatHop: '随拍跳动',
      hWave: '横向波浪', heartbeat: '心跳', orbitSmall: '小圆周运动', jelly: '果冻', scanBand: '扫描带',
      noiseDrift: '噪点漂移', tilt: '翘翘板', zoomSlow: '缓慢推近', stretchPulse: '随拍横向拉伸', glitchJump: '偶尔错位',
      echoTrail: '残影拖尾', glowFlicker: '烛火摇曳', windGust: '阵风', dangle: '悬吊', eqBounce: '随音量伸缩',
      flashBox: '随拍反转', glintSweep: '光泽扫过', flipSwap: '偶尔翻面', shadowSway: '影子摇晃', magnetJiggle: '磁力',
      typeRattle: '打字震动', focusRack: '移焦', pluckString: '拨弦'
    },
    exit: {
      cut: '直切', explode: '爆散', fall: '崩落', drift: '雾散', slice: '切片退场',
      wipe: '擦除退场', shrink: '收缩', blur: '模糊退场', stretch: '伸缩退场', scatter: '飞散',
      glitch: '故障退场', sinkMask: '下沉', riseOut: '向上消失', slideOutL: '向左滑出', slideOutR: '向右滑出',
      flipOutX: '关门', flipOutY: '啪地倒下', foldOut: '折叠收起', squash: '压扁', trackOutWide: '字距散开',
      collapse: '吸入', zoomThrough: '冲向镜头', zoomFar: '退向远方', spinOut: '旋转消失', twist: '扭转',
      waveOut: '波浪崩解', blurOutStagger: '逐字模糊', undraw: '回到线稿', outlineOut: '填色褪去', irisClose: '光圈',
      diagWipeOut: '斜向擦除', blindsClose: '百叶窗', checkerOut: '棋盘格', splitApart: '上下裂开', vSliceDrop: '纵向切片掉落',
      melt: '融化', dissolve: '碎散', backspace: '退格删除', scrambleOut: '变成符号', glitchDissolve: '化为方块',
      echoOut: '残响', whipOut: '急甩', gravity: '重力坠落', popOut: '迸裂', burn: '烧毁',
      sweepCover: '横条遮盖', shatterLite: '四分飞散', peelOff: '撕下贴纸', crumpleOut: '揉成纸团丢掉', tearOut: '撕掉',
      scorchOut: '烧焦消失', overexposeOut: '过曝泛白', scanOut: '扫描线消除', stripesOut: '条纹消除', halftoneOut: '化为网点',
      eraserOut: '黑板擦擦掉', vacuumOut: '吸入一点', sandOut: '化沙飞散', shredOut: '碎纸机', dominoOut: '骨牌倒下',
      hingeOut: '单边脱落', rocketOff: '发射升空', bounceOff: '弹跳离开', balloonOff: '气球飞走', deflateOut: '泄气飞走',
      hazeOut: '消失于热浪', glassBreak: '玻璃碎裂', zipOut: '拉链', clapShut: '中央闭合', lampOff: '熄灯',
      slotOut: '老虎机转动', clockOut: '时钟擦除', matrixOut: '数字雨', tornadoOut: '龙卷风', rollUpOut: '卷起',
      snakeOut: '排队离开', flutterOut: '飘落', rollOff: '滚走', fanClose: '收起扇子', rgbSplitOut: '分色',
      shockOut: '冲击波', floodOut: '淹没', slashOut: '一刀两断', mosaicOut: '马赛克', scribbleOut: '乱涂抹消',
      candleOut: '吹熄'
    },
    decor: {
      brackets: '框角标记', rings: '座标圆', dots: '点状圆环', arrows: '箭头', slash: '斜线',
      sparks: '火花', leaders: '引线', waveform: '波形', barcode: '条码', grid: '网格',
      stripes: '条纹', blobs: '墨渍', bars: '粗糙色带', shapes: '几何图形', counter: '大数字',
      crosshair: '十字准线', cropMarks: '裁切标记', reticle: '锁定框', radar: '雷达', progressRing: '进度环',
      timecodeBar: '时间码', rulerEdge: '边缘尺规', dimension: '尺寸线', indexNum: '流水号', dateStamp: '相片日期',
      qrBlock: 'QR 风格方块', glitchRects: '故障碎片', concentricSquares: '同心方框', triangleSpin: '旋转三角', lineBurst: '放射线',
      plusGrid: '十字网格', guides: '辅助线', waveLine: '波浪线', spiralLine: '漩涡', halftonePatch: '网点',
      checkerStrip: '棋盘格带', beatRing: '节拍圆环', orbitDots: '环绕圆点', constellation: '星座', confetti: '彩纸',
      petals: '花瓣', rainStreaks: '雨丝', snow: '雪', lightLeak: '漏光', bokeh: '散景光点',
      speedCorner: '集中线', risingParticles: '上升粒子', twinkle: '闪烁星光', brushStroke: '笔刷痕', tapePieces: '纸胶带',
      scribbleCircle: '手绘圈', scribbleUnder: '手绘底线', crossOut: '推敲笔记', highlightMark: '荧光笔', heartsStars: '爱心与星星',
      watermarkKanji: '浮水印大字', verticalStrip: '竖排条', romajiLine: '罗马字', bracketsJP: '方头括号', seal: '落款',
      kamon: '家纹', seigaiha: '青海波', asanoha: '麻叶纹', hanabi: '烟火', chochin: '灯笼',
      shimenawa: '注连绳', sensu: '扇子', tsukiKumo: '云中月', momiji: '枫叶', namiGashira: '浪头',
      kasumi: '霞', hexGrid: '六角网格', spectrumRing: '环形频谱', dataColumns: '数据列', spinner: '加载中',
      headingTape: '方位刻度', glyphLock: '文字锁定', atomOrbit: '原子轨道', sonarArcs: '声波', circuit: '电路',
      swatches: '色票', ruledLines: '横线笔记', registration: '套准标记', punchHoles: '打孔', staple: '钉书针',
      paperClip: '回纹针', indexTabs: '索引标签', vines: '藤蔓', cloudPuffs: '云朵', starField: '星空',
      moonPhases: '月相', sunRays: '阳光', rainRipples: '雨滴涟漪', bubbles: '肥皂泡', smoke: '烟',
      dandelion: '蒲公英', fireflies: '萤火虫', memphis: '孟菲斯', zigzagRibbon: '锯齿缎带', polkaPatch: '圆点',
      stripeCircle: '条纹圆', decoCorners: '装饰角', halfCircles: '半圆堆叠', loopArrows: '循环箭头', starburst: '星芒',
      tally: '画正字', cursorClick: '光标', windowChrome: '窗口', progressBar: '进度条', toggleSwitch: '切换开关',
      notifBell: '通知', likeCounter: '按赞数', mediaControls: '播放按钮', volumeBars: '音量', musicNotes: '音符'
    },
    treat: {
      none: '无', outline: '空心字', outlineFill: '描边', doubleOutline: '双层描边', extrude: '立体字',
      longShadow: '长阴影', hardShadow: '错位阴影', softShadow: '柔和阴影', glow: '发光', marker: '荧光笔',
      underline: '底线', strike: '删除线', boxed: '方框字', gradientV: '垂直渐变', splitColor: '上下双色',
      halftone: '网点', stripes: '条纹', hatch: '斜线', dotted: '点线轮廓', alternate: '交错配色',
      italic: '斜体', wide: '扁平字', tall: '瘦长字', echoOutline: '轮廓残响', emphasisDots: '着重号',
      neonOutline: '霓虹灯管', chrome: '镀铬', rainbow: '彩虹色', glitchSplit: '色版错位', shadowStack: '多重阴影',
      stencilGap: '镂空字', waterline: '水位', karaoke: '卡拉 OK', sizeWave: '大小节奏', rotateAlt: '摇摆字',
      baselineShift: '高低错落', fauxBold: '超粗', circled: '圆圈字', bracketsQuote: '引号', reflection: '倒影',
      inline: '内框线', sticker: '贴纸描边', gradientSweep: '光泽扫过', kerningWide: '宽字距', monoGrid: '稿纸风',
      outlineOffset: '错位空心字', toneShadow: '网点阴影', fadeChars: '余韵', cutShift: '切割错位', focusPull: '模糊移焦',
      spotChar: '单字标记', ransom: '剪贴字'
    },
    bg: {
      none: '素色', auroraRibbons: '极光', meshBlobs: '网格渐变', duotoneSweep: '双色扫动', horizonGlow: '行星边缘',
      seigaiha: '青海波', asanoha: '麻叶纹', houndstooth: '千鸟格', herringbone: '人字纹', argyle: '菱格纹',
      tartan: '苏格兰格纹', chevron: 'V 形纹', isoCubes: '立方体', hexGrid: '六角网格', triTess: '三角马赛克',
      moire: '摩尔纹', squareTunnel: '方形隧道', spiralArms: '漩涡', topoLines: '等高线', ridgePlot: '山脊线图',
      starfield: '星空', nightMoon: '月夜', skyline: '街景', sunsetSun: '夕阳', oceanWaves: '海浪',
      rainWindow: '雨窗', snowLayers: '雪', fireworks: '烟火', cloudLayers: '云', mountains: '山峦',
      filmStrip: '胶片', vhsBand: 'VHS 噪点', tornPaper: '撕纸', godRays: '光芒', vignettePulse: '彩色暗角',
      kaleidoscope: '万花筒', marble: '大理石', paperCut: '剪纸', sunburst: '放射', concentric: '同心圆',
      halftoneFade: '网点渐变', bigStripes: '大斜纹', splitV: '左右双色', splitH: '上下双色', splitDiag: '斜向双色',
      gradientSweep: '渐变', spotlight: '聚光灯', tvBars: '电视彩条', checker: '棋盘格', bigChar: '巨大文字',
      speedLines: '集中线', scanBars: '扫描线带', dotGrid: '点状网格', retroGrid: '复古网格', bokehBg: '散景光点',
      particlesBg: '飞舞粒子', ripples: '涟漪', polka: '圆点', eqBars: '背景等化器', borderFrame: '粗框',
      letterbox: '电影黑边', noiseField: '噪点扰动'
    },
    cam: {
      push: '缓慢推近', orbitDrift: '环绕', barrelRoll: '桶滚', pendulumSway: '钟摆', focusIn: '对焦',
      rackFocus: '失焦', earthquake: '地震', floatNoise: '漂浮', vertigo: '晕眩变焦', tiltDown: '镜头下摇',
      spiralIn: '漩涡变焦', snapPan: '快速横摇', jelly: '果冻晃动', pullOut: '拉远', panL: '向左横摇',
      panR: '向右横摇', tiltUp: '镜头上摇', dutch: '斜角镜头', handheld: '手持', beatPunch: '随拍放大',
      whipIn: '急甩推入', crashZoom: '急速变焦', bounce: '弹跳', roll: '滚转', driftDiag: '斜向漂移',
      shakeHard: '剧烈摇晃', dollyIn: '推轨', stepZoom: '分段变焦'
    },
    fx: {
      chroma: '色彩错位跳动', shake: '摇晃', slice: '切片故障', block: '区块故障', invert: '反转',
      flash: '闪光', zoom: '缩放模糊', mosaic: '马赛克', radialChroma: '放射色差', bloomFlash: '光晕',
      bulge: '鱼眼', pixelSort: '像素排序', interlace: '交错扫描', macroBlock: '区块噪点', halftone: '网点',
      duotone: '双色调', ditherBit: '1 位抖动', rotateSnap: '角度急转', echoFrames: '残影回声', kaleido: '万花筒',
      bandInvert: '带状反转', lightRays: '光芒', anamorphic: '横向光斑', heartbeat: '心跳', tvStatic: '雪花噪点',
      dustScratches: '胶片划痕', filmAdvance: '胶片滚动', perspectiveTilt: '透视摇晃', ripple: '涟漪', focusLines: '集中线',
      speedLines: '速度线', starGlint: '星芒闪光', colorBars: '彩条', zoomStutter: '连续缩放', negativeRing: '反转圆环',
      edgeDetect: '边缘侦测', shatter: '玻璃碎裂', defocus: '失焦', snapshot: '快门', squash: '伸缩',
      scanBar: '扫描', loopScroll: '横向循环', panelWipe: '面板擦除', irisTrans: '光圈', doors: '门',
      blindsTrans: '百叶窗', rgbSplit: 'RGB 分离', smear: '横向拖影', vhsRoll: 'VHS 滚动', trackingNoise: '磁道噪点',
      mirrorFlash: '镜像', strobe: '频闪', posterize: '色调分离', hueShift: '色相偏移', tileShift: '磁砖错位',
      filmBurn: '胶片烧灼', whipBlur: '急甩模糊', blackFrame: '黑画格', whiteFrame: '白画格', gridRepeat: '分割画面',
      waveWarp: '波浪扭曲', pixelDrift: '像素偏移', zoomPunch: '缩放重击', lightSweep: '光束扫过', crtOff: '映像管关机',
      splitSlide: '上下滑移'
    },
    trans: {
      wipe: '边缘擦除', diagonalWipe: '斜带擦除', clockWipe: '时钟擦除', irisOpen: '光圈开启', pushSlide: '推移',
      cover: '覆盖', uncover: '揭开', zoomThrough: '穿越缩放', doorsOpen: '对开门', blinds: '百叶窗转场',
      checker: '棋盘格转场', blockDissolve: '方块崩解', whipPan: '急甩横摇', spinOut: '旋转转出', inkBlob: '墨渍',
      shatterTiles: '磁砖崩落', sliceShift: '长条错位', cubeTurn: '立方体', flashCross: '闪光转场', pixelate: '马赛克转场'
    }
  };
  for (const group of J.GROUP_KEYS) {
    const table = J.registry(group), names = titles[group] || {};
    for (const key of Object.keys(table)) if (names[key]) table[key].name = names[key];   // includes the special title / interlude layouts
  }
})();

/* part sets (horror / typo / kinetic): names, styles and the horror mood */
(() => {
  'use strict';
  const P = {"layout": {"hrFlashlight": "手电筒", "hrDoorGap": "门缝", "hrWallScrawl": "墙上涂写", "hrCctv": "监控屏幕", "hrOuija": "通灵板", "hrMissing": "寻人启事", "hrWrongOne": "唯一不对的字", "hrRisingDark": "从黑暗爬出", "hrRedacted": "涂黑文件", "hrStaticTv": "雪花电视", "hrSpiritPhoto": "灵异照片", "hrWrongShadow": "不对劲的影子", "tyKeySplit": "大字夹排", "tyCropGiant": "出框大字", "tyCross": "十字排", "tyBandHide": "带状遮字", "tyRuby": "标音注记", "tyBaseline": "格线排版", "tyScaleSteps": "字级递增", "tyJustify": "等宽堆叠", "tyIndexTable": "字表", "tySplitType": "断字错位", "tyErode": "渐削重复", "tyVRuler": "竖排刻度", "tyFullTrack": "满版字距", "tyStatCount": "字数显示", "tyMargin": "留白", "tyRotBlock": "旋转字块", "tySquare": "方块排", "tyLineFocus": "行中强调", "knSlamStack": "堆叠重击", "knQuarterTurn": "直角转向", "knSwapCenter": "逐字替换", "knZoomDive": "钻入字中", "knFlowSnap": "流动后对齐", "knSeesaw": "跷跷板", "knTypeSlam": "打字→重击", "knRhythmCuts": "逐字分镜", "knPathRide": "环形轨道", "knGearWords": "齿轮", "knCollide": "正面冲撞", "knTumble": "翻滚方块", "knReflow": "竖排转横排", "knPadGrid": "打击垫"}, "enter": {"hrBlinkCreep": "眨眼之间", "hrJumpScare": "突然跳出", "hrUneasy": "不安的出现", "hrVhold": "垂直同步", "hrMirrorSnap": "镜像字", "hrManifest": "缓缓浮现", "hrClawReveal": "爪痕浮现", "tyKeyFirst": "主字先行", "tyLineWipe": "逐行擦入", "tyZoomOne": "逐字放大", "tyUnderLift": "从底线升起", "tyDotGrow": "点化为字", "tyBracketOpen": "括号展开", "tyRetype": "打错重打", "tyRubyDrop": "从注音落下", "knWordSlam": "逐词重击", "knTypeToSlam": "打字→放大", "knReplaceIn": "替换登场", "knHingeDrop": "铰链落下", "knLoopIn": "绕圈进场", "knPushIn": "推入", "knInertia": "急刹车", "knWordSpin": "逐词旋转", "knDiveIn": "从镜头飞入", "knStretchOut": "伸展弹出"}, "exit": {"hrPulledDown": "被拖下去", "hrLookBack": "留下一字", "hrTurnAway": "转身背对", "hrShiver": "颤抖消失", "hrSwallow": "被黑暗吞没", "hrFlickerDie": "闪烁熄灭", "hrDrain": "滴落", "tyStrike": "划线删除", "tyToDot": "缩回圆点", "tyLineFeed": "换行送出", "tyBracketClose": "括号合上", "tyToIndex": "化为编号", "tyKeyLast": "留下一字", "tyUnderSink": "沉入底线", "tyFoldVert": "折成竖排", "knWordKick": "逐词踢飞", "knPushOut": "推出退场", "knDiveGlyph": "冲入一字", "knLaunch": "急起步", "knWordBlink": "逐词熄灭", "knCloseGap": "收拢消失", "knJumpCutOut": "跳切", "knStackAway": "叠起落下"}, "hold": {"hrTwitch": "抽搐", "hrStare": "凝视的字", "hrLagOne": "慢一拍的字", "hrFlickerLight": "将熄的灯", "tyKeyPulse": "主字脉动", "tyReadCursor": "阅读光标", "tyOutlineBlink": "空心闪烁", "tyTrackStep": "字距跳段", "knWordPulse": "逐词节拍", "knCounterRock": "反向摇摆", "knWordRide": "词语冲浪", "knTickShift": "滴答位移", "knBeatLean": "随拍倾斜", "knGapBreath": "词间呼吸"}, "decor": {"hrScratches": "抓痕", "hrSigil": "魔法阵", "hrWatchEye": "注视之眼", "hrStaticPatch": "杂讯碎片", "hrDustBeam": "光束与尘埃", "hrDrips": "垂落的墨", "hrCracks": "裂痕", "tyColophon": "版权页", "tyRunningHead": "书眉页码", "tyGlyphBody": "字身分割线", "tyTextRule": "文字线条", "tyTypeScale": "字级样本", "tyBigPunct": "巨大引号", "knSpeedTrail": "跟随速度线", "knWordTicks": "词数计数器"}, "treat": {"hrInkBleed": "晕染滴落", "hrEroded": "风化", "hrRedact": "涂黑", "hrDoubleExp": "双重曝光", "tyHollowKey": "单字镂空", "tyHeadRules": "天地线", "tyHeadBig": "首字放大", "tyIndexSup": "字序号", "knWordScale": "大小词", "knWordPlate": "逐词反白"}, "bg": {"hrFailingLamp": "将熄的灯", "hrCorridor": "昏暗走廊", "hrMold": "蔓延的污渍", "hrDeadTrees": "枯树林"}, "cam": {"hrNervous": "惊恐手持", "hrDutchSnap": "突然倾斜", "knReadPan": "随读平移", "knTiltKick": "逐词倾斜", "knCardFlip": "翻牌", "knShearKick": "斜切弹动", "knJumpCut": "跳切", "knRushIn": "从远处冲来"}, "fx": {"hrSubliminal": "潜意识闪现", "hrSignalLoss": "信号中断", "hrPassingShadow": "掠过的影子"}, "trans": {"hrStaticCut": "杂讯转场", "hrBlink": "眨眼", "tyRuleWipe": "格线擦换", "tyGridCells": "稿纸格填入", "knCornerSwing": "转角回旋", "knStutterCut": "节奏跳切", "knStripSlam": "条幅落下"}};
  for (const [g, m] of Object.entries(P)) { const t = J.registry(g) || {}; for (const [k, n] of Object.entries(m)) if (t[k]) t[k].name = n; }
  const S = {"hrRuin": ["废墟", "褪色灰绿、锈红与回响的宋体"], "hrNightRec": ["深夜录像", "漆黑画面、监控影像的白与红、雪花噪点"], "hrCurse": ["诅咒之信", "泛黄信纸、褪色墨迹与暗红笔迹"]};
  for (const [k, [n, d]] of Object.entries(S)) if (J.STYLES[k]) { J.STYLES[k].name = n; J.STYLES[k].desc = d; }
  if (J.MOODS.horror) J.MOODS.horror.name = "恐怖";
})();
